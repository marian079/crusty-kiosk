import type { Express } from "express";
import { createServer, type Server } from "http";
import { db } from "./db";
import {
  categories,
  products,
  orders,
  orderItems,
  insertOrderSchema,
} from "@shared/schema";
import { eq } from "drizzle-orm";
import { z } from "zod";
import crypto from "crypto";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all categories
  app.get("/api/categories", async (_req, res) => {
    try {
      const result = await db.select().from(categories);
      res.json(result);
    } catch (error: any) {
      res.status(500).json({ message: "Error fetching categories: " + error.message });
    }
  });

  // Get all products or filter by category
  app.get("/api/products", async (req, res) => {
    try {
      const categoryId = req.query.categoryId as string | undefined;

      const result = categoryId
        ? await db.select().from(products).where(eq(products.categoryId, categoryId))
        : await db.select().from(products);

      res.json(result);
    } catch (error: any) {
      res.status(500).json({ message: "Error fetching products: " + error.message });
    }
  });

  // Get single product
  app.get("/api/products/:id", async (req, res) => {
    try {
      const result = await db
        .select()
        .from(products)
        .where(eq(products.id, req.params.id));

      const product = result[0];
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }

      res.json(product);
    } catch (error: any) {
      res.status(500).json({ message: "Error fetching product: " + error.message });
    }
  });

  // Create new order
 app.post("/api/orders", async (req, res) => {
  try {
    const orderItemSchema = z.object({
      productId: z.string(),
      productName: z.string(),
      productPrice: z.string(), // decimal as string
      quantity: z.number().int().positive(),
    });

    const requestSchema = z.object({
      order: insertOrderSchema.extend({
        orderNumber: z.number().int().positive(), // ✅ adăugat
      }),
      items: z.array(orderItemSchema).min(1),
    });

    const validatedData = requestSchema.parse(req.body);
    const orderId = validatedData.order.id ?? crypto.randomUUID();

    // Insert order
    await db.insert(orders).values({
      id: orderId,
      orderNumber: validatedData.order.orderNumber,
      paymentMethod: validatedData.order.paymentMethod,
      total: validatedData.order.total,
      status: validatedData.order.status ?? "pending",
      customerName: validatedData.order.customerName ?? null,
    });

    // Insert order items
    await db.insert(orderItems).values(
      validatedData.items.map((item) => ({
        id: crypto.randomUUID(),
        orderId,
        productId: item.productId,
        productName: item.productName,
        productPrice: item.productPrice,
        quantity: item.quantity,
      }))
    );

    res.status(201).json({ message: "Order created", orderId });
  } catch (error: any) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({
        message: "Invalid order data",
        errors: error.errors,
      });
    }
    res.status(500).json({ message: "Error creating order: " + error.message });
  }
});

  // Get all orders
  app.get("/api/orders", async (_req, res) => {
    try {
      const result = await db.select().from(orders);
      res.json(result);
    } catch (error: any) {
      res.status(500).json({ message: "Error fetching orders: " + error.message });
    }
  });

  // Get single order with items
  app.get("/api/orders/:id", async (req, res) => {
    try {
      const orderResult = await db
        .select()
        .from(orders)
        .where(eq(orders.id, req.params.id));

      const order = orderResult[0];
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }

      const items = await db
        .select()
        .from(orderItems)
        .where(eq(orderItems.orderId, req.params.id));

      res.json({ order, items });
    } catch (error: any) {
      res.status(500).json({ message: "Error fetching order: " + error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
